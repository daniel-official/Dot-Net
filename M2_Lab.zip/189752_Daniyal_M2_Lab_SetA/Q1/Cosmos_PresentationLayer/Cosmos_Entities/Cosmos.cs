﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosmos_Entities
{
    public class Cosmos
    {  
        //properties declaration
        public int FlatNo { get; set; }
        public string Block { get; set; }
        public String ResidentName { get; set; }
        public DateTime Incidentdate { get; set; }
        public int ContactNo { get; set; }
        public String IssueType { get; set; }
        public String Description { get; set; }
    }
}
