﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosmos_Exceptions
{
    public class Cosmos_EXP:Exception
    {
        public Cosmos_EXP(string message) : base(message) { }
    }
}
