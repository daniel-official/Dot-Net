﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosmos_Exceptions;
using Cosmos_DataAccessLayer;
using System.Data.SqlClient;
using System.Data;
using Cosmos_Entities;
using Cosmos_Exceptions;
using System.Configuration;


namespace Cosmos_DataAccessLayer
{
    public class CosmosDAL
    {
        static SqlConnection cn = null;  //creating connection object
        static SqlCommand cmd = null;    //creating command object
        public static int AddCosmosDAL(Cosmos objcosmos)
        {
            int Incidentid;

            try
            {
                //setting connection string
                cn = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;User ID=sqluser;Password=sqluser");
                cmd = new SqlCommand("DANIM2189752.USP_INSERT_COSMOSAPPARTMENTS", cn); 
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter iNo = new SqlParameter("@incidentid", SqlDbType.Int);
                iNo.Direction = ParameterDirection.Output;
                //passing parameter values
                cmd.Parameters.Add(iNo);
                cmd.Parameters.AddWithValue("@flatno", objcosmos.FlatNo);
                cmd.Parameters.AddWithValue("@block", objcosmos.Block);
                cmd.Parameters.AddWithValue("@residentname", objcosmos.ResidentName);
                cmd.Parameters.AddWithValue("@incidentdate", objcosmos.Incidentdate);
                cmd.Parameters.AddWithValue("@contactno", objcosmos.ContactNo);
                cmd.Parameters.AddWithValue("@issuetype", objcosmos.IssueType);
                cmd.Parameters.AddWithValue("@description", objcosmos.Description);
                //opening connection
                cn.Open();
                //executing query
                cmd.ExecuteNonQuery();

                Incidentid = Convert.ToInt32(cmd.Parameters["@incidentid"].Value);

                //return Incidentid
                return Incidentid;
            }
            catch (Exception e1)
            {
                //throwing exception
                throw new Cosmos_EXP(e1.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();   //closing connection
            }

   

        }
    }
}
