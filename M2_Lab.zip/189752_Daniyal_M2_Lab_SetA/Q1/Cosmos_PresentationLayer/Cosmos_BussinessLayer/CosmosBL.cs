﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosmos_DataAccessLayer;
using Cosmos_Entities;
using Cosmos_Exceptions;
using Cosmos_DataAccessLayer;

namespace Cosmos_BussinessLayer
{
    //bussiness layer for Cosmos
    public class CosmosBL
    {
       //Creating add cosmos function in bussinesslayer
        public static int AddCosmosBL(Cosmos objCosmos)
        {
            int Incidentid; //declaring Incidentid
            Incidentid = CosmosDAL.AddCosmosDAL(objCosmos);
            return Incidentid; //returning Incidentid
        }
    }
}
