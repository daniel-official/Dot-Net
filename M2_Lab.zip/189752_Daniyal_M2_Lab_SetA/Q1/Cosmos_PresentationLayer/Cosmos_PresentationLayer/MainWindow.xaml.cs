﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Cosmos_Exceptions;
using Cosmos_Entities;
using Cosmos_BussinessLayer;

namespace Cosmos_PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            //insert function in presentation

            try
            {
                Cosmos objCosmos = new Cosmos(); //creating object
                //Assigning values
                objCosmos.FlatNo = int.Parse(txtfno.Text);
                objCosmos.Block = ((ComboBoxItem)cbblock.SelectedValue).Content.ToString();
                objCosmos.ResidentName = txtresname.Text;
                objCosmos.Incidentdate = (DateTime)dpincdate.SelectedDate;
                objCosmos.ContactNo = int.Parse(txtcno.Text);
                objCosmos.IssueType = ((ComboBoxItem)cbissue.SelectedValue).Content.ToString();
                txtdes.SelectAll();
                objCosmos.Description = txtdes.Selection.Text;
                
                //calling addcosmosBl function
                int Incidentid = CosmosBL.AddCosmosBL(objCosmos);

                //displaying Incidentid
                MessageBox.Show("Incident Id : " + Incidentid);
            }
            catch (Exception e1)
            {
                //exception block
                MessageBox.Show(e1.Message);
            }
        }
    }
}
