﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Lab12_2
{
    public class Program
    {
        
        static void Main(string[] args)
        {
            
            
            CopyFile();
        }
        static void CopyFile() {
            Console.WriteLine("Enter the source file with Extension:");
            string strSource = @"D:\dgyanapr\Lab\Lab12_2\" + Console.ReadLine();
            Console.WriteLine("Enter the destination file with Extension:");
            string strDestination = @"D:\dgyanapr\Lab\Lab12_2\Destination\"+Console.ReadLine();

            try
            {
            if (File.Exists(strSource))
            {

                File.Copy(strSource, strDestination);
                if (File.Exists(strDestination))
                {
                    Console.WriteLine("Copied successfully");
                }
            }
                if (!File.Exists(strSource)) {
                    throw (new FileDoesNotFound(" FileName Does Not Found"));
                }
            
            }
            catch (FileDoesNotFound e) {
               Console.WriteLine("USER DEFINED EXCEPTION! : "+e.Message);
              
            }
        }

    }
}
public class FileDoesNotFound : Exception
{
    public FileDoesNotFound(string message):base(message){}
    }
