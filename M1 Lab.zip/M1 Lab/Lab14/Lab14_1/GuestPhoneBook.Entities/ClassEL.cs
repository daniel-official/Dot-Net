﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBookEntities
{
    public class ClassEL
    {
        private int id;
        public int ID { get; set; }
        private string name;
        public string Name { get; set; }
        private string phoneNo;
        public string PhoneNo { get; set; }
        private int designationID;
        public int DesignationId { get; set; }
        private int departmentId;
        public int DepartmentId { get; set; }


        

    }

    

}
