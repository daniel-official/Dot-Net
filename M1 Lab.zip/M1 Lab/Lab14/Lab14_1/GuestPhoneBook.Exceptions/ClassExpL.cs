﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBookExceptions
{
    public class ClassExpL:ApplicationException
    {
        
        public ClassExpL() : base() { }

        public ClassExpL(string message) : base(message) { }

        public ClassExpL(string message, Exception InnerException) : base(message,InnerException) 
        {

        }
    }

    
}
