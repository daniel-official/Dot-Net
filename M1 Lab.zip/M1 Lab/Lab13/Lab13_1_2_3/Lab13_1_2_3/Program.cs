﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.IO;


namespace Lab13_1_2_3
{
    class Program
    {
        static List<Contact> obj = new List<Contact>();
        static Contact contact1 = new Contact();
        static void Main(string[] args)
        {
            int choice;
            char conti;
            do
            {
                Console.WriteLine("\n\n 1-add Contact");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddContact();
                        break;
                    default:
                        Console.WriteLine("please select a valid option.");
                        break;

                }
                Console.WriteLine("\n\ndo you wish to continue 'y' or 'n'.");
                conti = Convert.ToChar(Console.ReadLine());
            } while (conti == 'y');
           
        }
        static void AddContact()
        {
            Console.WriteLine("-------------Add contact------------------\n\n");
            

            Console.WriteLine("Enter Contact No:");
            contact1.ContactNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Contact Name:");
            contact1.ContactName = Console.ReadLine();
            Console.WriteLine("Enter Cell no:");
            contact1.CellNo = Console.ReadLine();


            obj.Add(contact1);
            //binarySerialization();
            SoapSerialization();

            Console.WriteLine("Record Inserted");
            BinaryDeserialization();
            Console.WriteLine("Record Deserialized");

        }

        static void binarySerialization()
        {
            FileStream objFS = new FileStream(@"D:\dgyanapr\M1 Lab\Lab13\Lab13_1_2_3\Files\ContactBinary.dat", FileMode.Append, FileAccess.Write, FileShare.Read);
            BinaryFormatter objBinF = new BinaryFormatter();
            objBinF.Serialize(objFS, obj);
            objFS.Close();
            Console.WriteLine("Serialization done");
        }

        static void BinaryDeserialization()
        {
            FileStream objFS = new FileStream(@"D:\dgyanapr\M1 Lab\Lab13\Lab13_1_2_3\Files\ContactBinary.dat", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
            BinaryFormatter binary = new BinaryFormatter();
            Contact objNewCon = binary.Deserialize(objFS) as Contact;
            objFS.Close();
            Console.WriteLine("-----------------Binary DeSerialization--------------");
            Console.WriteLine("-- Employee Detail--");

            Console.WriteLine("Contact NO : {0},Contact NAME:{1},Cell no:{2}", contact1.ContactNo, contact1.ContactName, contact1.CellNo);
        }
        static void SoapSerialization()
        {
            FileStream objFS = new FileStream(@"D:\dgyanapr\M1 Lab\Lab13\Lab13_1_2_3\Files\ContactSoap.xml", FileMode.Append, FileAccess.Write, FileShare.Read);
            SoapFormatter objSF = new SoapFormatter();
            objSF.Serialize(objFS, contact1);
            objFS.Close();
            Console.WriteLine("SoapSerialization done");
        }
    }
}