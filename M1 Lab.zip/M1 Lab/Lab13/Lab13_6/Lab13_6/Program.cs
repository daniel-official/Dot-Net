﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Lab13_6
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream stream = new FileStream(@"D:\dgyanapr\M1 Lab\Lab13\Lab13_6\Files\sss.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            Student s = new Student(101, "Daniyal", "Coimbatore", "BCA");

            formatter.Serialize(stream, s);
            Console.WriteLine("1001, daniyal, Coimbatore, BCA");
            stream.Close();
        }
    }
}
