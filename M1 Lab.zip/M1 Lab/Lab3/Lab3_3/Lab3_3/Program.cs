﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_3
{
    class Program
    {
        static Cars objCars = new Cars();
        static void Main(string[] args)
        {
            char c;
            do
            {
                Console.WriteLine("Cars portal");
                Console.WriteLine("Press 1 to add a car");
                Console.WriteLine("Press 2 to update");
                Console.WriteLine("Press 3 to delete");
                Console.WriteLine("Press 4 to serach cars");
                Console.WriteLine("Press 5 to get cars");

                int choice;
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddCar();
                        break;

                    case 2:
                        UpdateCar();
                        break;

                    case 3:
                        DeleteCar();
                        break;

                    case 4:
                        SearchCar();
                        break;

                    case 5:
                        GetCars();
                        break;

                    case 6:
                        Environment.Exit(0);
                        break;

                    default:
                        break;
                }
                Console.WriteLine("Do you want to Continue? press 'y' to Continue and 'n' to Exit.");
                c = Convert.ToChar(Console.ReadLine());
            } while (c == 'y');


        }

        static void AddCar()
        {
            string make;
            string model;
            string year;
            int salePrice;

            Console.WriteLine("========== Adding car details============");
            Console.WriteLine("Enter card details :");
            Console.WriteLine("Enter make:");
            make = Console.ReadLine();
            Console.WriteLine("Enter model:");
            model = Console.ReadLine();
            Console.WriteLine("Enter year:");
            year = Console.ReadLine();
            Console.WriteLine("Enter sale price :");
            salePrice = Convert.ToInt32(Console.ReadLine());
            Car objCar = new Car { Make = make, Model = model, Year = year, SalePrice = salePrice };
            objCars.AddCar(objCar);

        }

        static void UpdateCar()
        {
            string make;
            string model;
            string year;
            int salePrice;


            Console.WriteLine("Enter card details :");
            Console.WriteLine("Enter make:");
            make = Console.ReadLine();
            Console.WriteLine("Enter model:");
            model = Console.ReadLine();
            Console.WriteLine("Enter year:");
            year = Console.ReadLine();
            salePrice = Convert.ToInt32(Console.ReadLine());
            Car objCar = new Car { Make = make, Model = model, Year = year, SalePrice = salePrice };
            objCars.UpdateCar(objCar);

        }

        static void DeleteCar()
        {
            string make;

            Console.WriteLine("Enter card details :");
            Console.WriteLine("Enter make:");
            make = Console.ReadLine();

            objCars.DeleteCar(make);

        }

        static void SearchCar()
        {
            string make;

            Console.WriteLine("Enter Car Details to Search ");
            Console.WriteLine("Enter Make :");
            make = Console.ReadLine();
            Car objCar = objCars.SearchCar(make);
            Console.WriteLine("Make : {0}, Model : {1}, Year : {2}, SalePrice :{3}", objCar.Make, objCar.Model, objCar.Year, objCar.SalePrice);
        }

        static void GetCars()
        {
            Car[] objCarsArray = objCars.GetCars();

            foreach (Car objCar in objCarsArray)
            {
                if (objCar != null)
                {
                    Console.WriteLine("Make : {0}, Model : {1}, Year : {2}, SalePrice :{3}", objCar.Make, objCar.Model, objCar.Year, objCar.SalePrice);
                }

            }
        }
    }
}
