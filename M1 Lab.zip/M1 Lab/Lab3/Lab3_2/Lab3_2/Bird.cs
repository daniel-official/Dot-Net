﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_2
{
    public class Bird
    {
        public string Name;
        public double Maxheight;
        public Bird() //Default Constructor
        {
            this.Name = "MountainEagle";
            this.Maxheight = 500;
            //
            // TODO: Add constructor logic here
            //
        }
        public Bird(string birdname, double max_ht) //Overloaded Constructor
        {
            this.Name = birdname;
            this.Maxheight = max_ht;
        }
        public void fly()
        {
            Console.WriteLine(Name + " is flying at altitude " + Maxheight);
        }
        public void fly(double AtHeight)
        {
            if (AtHeight <= this.Maxheight)
                Console.WriteLine(Name + " can flying at " + AtHeight.ToString());
            else
                Console.WriteLine(Name + " cannot fly at " + AtHeight.ToString());
        }
    }
}
