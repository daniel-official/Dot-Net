﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                char choice;
                do
                {
                    Console.WriteLine("Enter Emp ID :");
                    int EmpID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Emp Name :");
                    string Name = Console.ReadLine();
                    Console.WriteLine("Enter FoundationMarks :");
                    int FMarks = Convert.ToInt32(Console.ReadLine());


                    Console.WriteLine("Enter WebBasicMarks :");
                    int WMarks = Convert.ToInt32(Console.ReadLine());


                    Console.WriteLine("Enter DotNetMarks :");
                    int DMarks = Convert.ToInt32(Console.ReadLine());

                    ParticipantsLib.Participants objParticipants = new ParticipantsLib.Participants(EmpID, Name, FMarks, WMarks, DMarks);
                    objParticipants.CalculateObtainedMarks();
                    objParticipants.CalculatePercentage();
                    double Percentage = objParticipants.GetPercentage();

                    Console.WriteLine("The Percentage of {0} is {1} ", Name, Percentage);
                    Console.WriteLine("Press 'y' to Continue and 'n' to Exit.");
                    choice = Convert.ToChar(Console.ReadLine());
                } while (choice == 'y');
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
