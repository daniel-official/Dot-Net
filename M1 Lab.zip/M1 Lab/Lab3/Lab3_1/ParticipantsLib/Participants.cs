﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParticipantsLib
{
    public class Participants
    {
        int empId;
        int fMarks;
        int dMarks;
        int wMarks;
        int obtainedMarks;
        int totalMarks = 300;
        double percentage;
        string name;
        static string cName;
        bool flag = true;

        public Participants()
        {


        }
        public Participants(int empId, string name, int fMarks, int dMarks, int wMarks)
        {
            this.empId = empId;
            this.name = name;
            this.fMarks = fMarks;
            this.wMarks = wMarks;
            this.dMarks = dMarks;

        }
        static Participants()
        {

            cName = "Corporate Unniversity";
        }



        public int EmpID
        { get { return empId; } set { empId = value; } }
        public string Name
        { get { return name; } set { name = value; } }
        public string CName
        { get { return cName; } set { cName = value; } }
        public int FMarks
        {
            get
            {
                return fMarks;
            }
            set
            {
                fMarks = value;
                valid();

            }
        }
        public int DMarks
        {
            get
            {
                return dMarks;
            }
            set
            {
                dMarks = value;
                valid();

            }
        }
        public int WMarks
        {
            get
            {
                return wMarks;
            }
            set
            {

                wMarks = value;
                valid();

            }
        }
        public int TotalMarks
        { get { return totalMarks; } set { totalMarks = value; } }
        public double Percentage
        { get { return percentage; } set { percentage = value; } }

        public void valid()
        {
            if (fMarks < 0 || fMarks > 100)
            {
                flag = false;
            }
            if (dMarks < 0 || dMarks > 100)
            {
                flag = false;
            }
            if (wMarks < 0 || wMarks > 100)
            {
                flag = false;
            }
            if (flag == false)
            {
                throw new Exception("Please enter valid number");
            }
        }




        public void CalculateObtainedMarks()
        {
            obtainedMarks = fMarks + dMarks + wMarks;
        }
        public void CalculatePercentage()
        {

            valid();
            percentage = Convert.ToDouble((obtainedMarks * 100) / totalMarks);
        }
        public double GetPercentage()
        {
            return percentage;
        }
    }
}
