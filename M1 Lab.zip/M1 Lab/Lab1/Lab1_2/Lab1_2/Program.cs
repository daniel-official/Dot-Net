﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double A, B, operation, result;
            Console.WriteLine("------------------Calculator Application---------------");
            char choice;
            do
            {
                Console.WriteLine("1-Addition");
                Console.WriteLine("2-Subtraction");
                Console.WriteLine("3-Multiplication");
                Console.WriteLine("4-Division");
                Console.WriteLine("5-Modulus");
                Console.WriteLine("6-Exit");

                Console.WriteLine("Enter the choice : ");
                operation = Convert.ToDouble(Console.ReadLine());
                CalculatorLib.CalcLib ObjCal = new CalculatorLib.CalcLib();


                switch (operation)
                {
                    case 1:
                        //Addition
                        Console.WriteLine("Enter the 1st value : ");
                        A = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the 2nd value : ");
                        B = Convert.ToDouble(Console.ReadLine());
                        result = ObjCal.Addition(A, B);
                        Console.WriteLine("Addition of two number is:" + result);
                        break;

                    case 2:
                        //Subtraction
                        Console.WriteLine("Enter the 1st value : ");
                        A = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the 2nd value : ");
                        B = Convert.ToDouble(Console.ReadLine());
                        result = ObjCal.Subtraction(A, B);
                        Console.WriteLine("Subtraction of two number is:" + result);
                        break;

                    case 3:
                        //Multiplication
                        Console.WriteLine("Enter the 1st value : ");
                        A = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the 2nd value : ");
                        B = Convert.ToDouble(Console.ReadLine());
                        result = ObjCal.Multiplication(A, B);
                        Console.WriteLine("Multiplition of two number is:" + result);
                        break;

                    case 4:
                        //division
                        Console.WriteLine("Enter the 1st value : ");
                        A = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the 2nd value : ");
                        B = Convert.ToDouble(Console.ReadLine());
                        result = ObjCal.Division(A, B);
                        Console.WriteLine("Division of two number is:" + result);
                        break;

                    case 5:
                        //Modulus
                        Console.WriteLine("Enter the 1st value : ");
                        A = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the 2nd value : ");
                        B = Convert.ToDouble(Console.ReadLine());
                        result = ObjCal.Modulus(A, B);
                        Console.WriteLine("Modulus of two number is:" + result);
                        break;

                    case 6:
                        //Exit
                        return;
                        

                    default:
                        Console.WriteLine("Please press a valid number...");
                        break;
                }

                Console.WriteLine("Do you want to continue? press Y otherwise press N");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y');

        }
    }
}
