﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int var;

            Console.WriteLine("Press Any number between 1 to 5:");


            var = Convert.ToInt32(Console.ReadLine());

            switch (var)
            {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    Console.WriteLine("You pressed number :" + var);
                    break;

                default:
                    Console.WriteLine("You pressed a invalid number");
                    break;


            }

        }
    }
}
