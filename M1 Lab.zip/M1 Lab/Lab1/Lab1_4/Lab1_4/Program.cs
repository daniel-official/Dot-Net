﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int rollNumber = 1001;
            string studentName = "Daniyal";
            byte age = 19;
            char gender = Convert.ToChar("m");
            DateTime dateOfBirth = Convert.ToDateTime("1999/08/18");
            string address = "Pune";
            float percentage = 68.4f;

            Console.WriteLine("Roll Number : " + rollNumber);
            Console.WriteLine("Name : " + studentName);
            Console.WriteLine("Age : " + age);
            Console.WriteLine("Gender : " + gender);
            Console.WriteLine("Date of Birth : " + dateOfBirth);
            Console.WriteLine("Address : " + address);
            Console.WriteLine("Percentage : " + percentage);
        }
    }
}
