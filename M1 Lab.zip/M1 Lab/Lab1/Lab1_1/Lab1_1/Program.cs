﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_1
{
    class Program
    {
        
            static void Main(string[] args)
            {
                EmployeeLib.Employee[] emp = new EmployeeLib.Employee[1];

                for (int i = 0; i < emp.Length; i++)
                {
                    emp[i] = new EmployeeLib.Employee();
                }

                for (int i = 0; i < emp.Length; i++)
                {
                    Console.WriteLine("-----------Employee Details--------------");
                    Console.WriteLine("Enter your EmployeeId:");
                    emp[i].EmployeeId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter your Name");
                    emp[i].EmployeeName = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Enter your Address");
                    emp[i].Address = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Enter your City");
                    emp[i].City = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Enter your Department");
                    emp[i].Department = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Enter your Salary");
                    emp[i].Salary = Convert.ToInt32(Console.ReadLine());
                }
                for (int i = 0; i < emp.Length; i++)
                {
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine("Employee Name is " + emp[i].EmployeeName + " and salary is " + emp[i].Salary);
                }
                Console.ReadKey();
            }
        
    }
}
