﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Convert;

namespace Lab6_1
{
    class Program
    {
        static void Main(string[] args)
        {
            // getDetails();
            try
            {
                WriteLine("---Enter the Customer Details---");
                WriteLine("Enter Customer ID :");
                int CustomerID = ToInt32(ReadLine());
                WriteLine("Enter Customer Name :");
                string CustomerName = (ReadLine());
                WriteLine("Enter Customer Address :");
                string Address = (ReadLine());
                WriteLine("Enter Customer City :");
                string City = (ReadLine());
                WriteLine("Enter Customer Phone Number :");
                double Phone = ToDouble(ReadLine());
                WriteLine("Enter Credit Limit :");
                double CreditLimit = ToDouble(ReadLine());

                Customer objCustomer = new Customer(CustomerID, CustomerName, Address, City, Phone, CreditLimit);
                objCustomer.exError();
            }
            catch (Exception ex)
            { WriteLine("Error :" + ex.Message); }
        }
    }
}
