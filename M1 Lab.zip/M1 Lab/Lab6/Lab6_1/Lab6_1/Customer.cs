﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Lab6_1
{
    public class Customer
    {
        int customerID;
        string customerName;
        string address;
        string city;
        double phone;
        double creditLimit;
        bool Flag = true;



        public Customer()
        {

        }

        public Customer(int customerID, string customerName, string address, string city, double phone, double creditLimit)
        {
            this.customerID = customerID;
            this.customerName = customerName;
            this.address = address;
            this.city = city;
            this.phone = phone;
            this.creditLimit = creditLimit;
        }

        public void exError()
        {

            if (creditLimit > 50000)
            {
                Flag = false;
            }
            else
            {
                display();
            }
            if (Flag == false)
            {
                throw new Exception("Invalid credit limit!");
            }

        }

        public int CustomerID
        { get { return customerID; } set { customerID = value; } }
        public string CustomerName
        { get { return customerName; } set { customerName = value; } }
        public string Address
        { get { return address; } set { address = value; } }
        public string City
        { get { return city; } set { city = value; } }
        public double Phone
        { get { return phone; } set { phone = value; } }
        public double CreditLimit
        { get { return creditLimit; } set { creditLimit = value; } }

        public void display()
        {
            WriteLine("---------customer details-----------");
            WriteLine("Customer ID :" + customerID);
            WriteLine("Customer Name :" + customerName);
            WriteLine("Customer Address :" + address);
            WriteLine("Customer City :" + city);
            WriteLine("Customer Phone Number :" + phone);
            WriteLine("Credit Limit :" + creditLimit);

        }


    }
}
