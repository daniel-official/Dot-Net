﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_4
{
    class ProductDemo
    {
        public object ProductId { get; set; }
        public object ProductName { get; set; }
        public object Price { get; set; }
        public object Quantity { get; set; }
        public double AmountPayable { get; set; }
    }
}
