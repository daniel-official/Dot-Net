﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lab2_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Boxing
            ProductDemo objProductDemo = new ProductDemo();
            Console.Write("Enter the ID of the product :");
            objProductDemo.ProductId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the name of the product :");
            objProductDemo.ProductName = Convert.ToString(Console.ReadLine());
            Console.Write("Enter price :");
            objProductDemo.Price = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Quantity :");
            objProductDemo.Quantity = Convert.ToDouble(Console.ReadLine());
            //double amountpayable = objProductDemo.Price * objProductDemo.Quantity;

            //UnBoxing
            int productId = Convert.ToInt32(objProductDemo.ProductId);
            string productName = objProductDemo.ProductName as string;
            double price = Convert.ToDouble(objProductDemo.Price);
            double quantity = Convert.ToDouble(objProductDemo.Quantity);
            double amountPayable = price * quantity;
            //
            objProductDemo.AmountPayable = amountPayable;



            Console.WriteLine("-----------------------Product Details-----------------------");
            Console.WriteLine("Product ID :" + productId);
            Console.WriteLine("Product Name :" + productName);
            Console.WriteLine("Price :" + price);
            Console.WriteLine("Quantity :" + quantity);
            Console.WriteLine("Amount Payable: " + objProductDemo.AmountPayable);
            Console.Read();
        }
    }
}
