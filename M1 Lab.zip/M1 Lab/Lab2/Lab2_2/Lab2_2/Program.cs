﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_2
{
    class Program
    {
        static int[,] Numbers = new int[5, 6];
        static void Main(string[] args)
        {
            TwoDArray();
            ResultArray();
            Console.ReadKey();
        }
        static void TwoDArray()
        {
            //input
            for (int i = 0; i < Numbers.GetLength(0); i++)
            {
                Console.WriteLine("Enter the values of Row " + i);
                for (int j = 0; j < Numbers.GetLength(1); j++)
                {
                    Numbers[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

        }

        static void ResultArray()
        {
            //output
            Console.WriteLine("The values are :");
            for (int i = 0; i < Numbers.GetLength(0); i++)
            {
                for (int j = 0; j < Numbers.GetLength(1); j++)
                {
                    Console.Write(Numbers[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
