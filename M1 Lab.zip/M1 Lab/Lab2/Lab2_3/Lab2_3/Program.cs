﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_3
{
    class Program
    {
        static void Main(string[] args)
        {
            OneDArray();
            Console.Read();

        }

        static void OneDArray()
        {
            string[] Cities = new string[5];

            Console.WriteLine("Enter the name of the Cities:");

            for (int i = 0; i < Cities.Length; i++)
            {
                Cities[i] = Console.ReadLine();
            }

            Console.WriteLine("-----------------------");
            Console.WriteLine("Name of the cities are:");

            foreach (var objCity in Cities)
            {
                Console.WriteLine(objCity);
            }
        }
    }
}
