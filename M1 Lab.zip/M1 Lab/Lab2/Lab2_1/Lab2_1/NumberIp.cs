﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_1
{
    struct NumberIp
    {
        public int number;


        public NumberIp(int num)
        {
            number = num;
        }

        public int Square()
        {
            int result;
            result = number * number;
            return result;
        }

        public int Cube()
        {
            int result;
            result = number * number * number;
            return result;
        }

        static void Main(string[] args)
        {
            int Sel;
            int Number;
            Console.WriteLine("------Choose the Action-----");
            Console.WriteLine("1-Square");
            Console.WriteLine("2-Cube");
            Sel = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the number: ");
            Number = Convert.ToInt32(Console.ReadLine());

            NumberIp objNumber = new NumberIp(Number);


            int result;
            switch (Sel)
            {
                case 1:
                    result = objNumber.Square();
                    Console.WriteLine("Square value is : " + result);
                    break;
                case 2:
                    result = objNumber.Cube();
                    Console.WriteLine("Cube value is : " + result);
                    break;

                default:
                    Console.WriteLine("press valid key...");
                    break;

            }

        }
    }
}
