﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public abstract class BankAccount : IBankAccount
    {
        protected double balance;
        protected BankAccountTypeEnum accountType;

        public abstract void CalculateInterest();

        public double Balance
        {
            get { return balance; }
            set { value = balance; }
        }

        public void Deposit(double amount)
        {
            balance += amount;
        }

        public double GetBalance()
        {
            return Balance;
        }

        public BankAccountTypeEnum AccountType
        {
            get
            {
                return accountType;
            }
            set
            {
                value = accountType;
            }
        }



        public abstract bool Withdraw(double amount);
        public abstract bool Transfer(IBankAccount toAccount, double amount);
    }
}
