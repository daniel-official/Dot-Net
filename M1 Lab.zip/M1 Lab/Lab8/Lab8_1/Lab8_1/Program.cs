﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Lab8_1
{
    class Program
    {

        static Hashtable objHashtable = new Hashtable();
        static void Main(string[] args)
        {

            char ch;
            do
            {
                Console.WriteLine("-----MENU-----");
                Console.WriteLine("\nPress 1 for Add Record\nPress 2 for Search Records\nPress 3 for Display Records\nPress 4 for Total Count of Records" +
                    "\nPress 5 for Remove Records\nPress 6 for Exit");

                int choice;
                choice = Convert.ToInt32(Console.ReadLine());


                switch (choice)
                {
                    case 1:
                        AddRecord_Hashtable();
                        Console.ReadLine();
                        break;
                    case 2:
                        SearchRecords_Hashtable();
                        Console.ReadLine();
                        break;
                    case 3:
                        DisplayRecords_Hashtable();
                        Console.ReadLine();
                        break;
                    case 4:
                        CountRecords_Hashtable();
                        Console.ReadLine();
                        break;
                    case 5:
                        RemoveRecord_Hashtable();
                        Console.ReadLine();
                        break;
                    case 6:
                        Environment.Exit(0);

                        break;
                    default:
                        Console.WriteLine("Error Occurred in your program!");
                        break;
                }

                Console.WriteLine("If you want to continue press 'y' else press 'n' for exit");
                ch = Convert.ToChar(Console.ReadLine());

            }
            while (ch == 'y' || ch == 'Y');
          

        }
        static void AddRecord_Hashtable()
        {
            Console.WriteLine("Enter Key:");
            string key = Console.ReadLine();
            Console.WriteLine("Enter Value:");
            string value = Console.ReadLine();
            objHashtable.Add(key, value);


        }
        static void SearchRecords_Hashtable()
        {
            Console.WriteLine("Enter Value to be Searched");
            string value = Console.ReadLine();
            bool flag = objHashtable.ContainsValue(value);

            if (flag == true)
            {
                Console.WriteLine("Value is available in collection:" + value);
            }
            else
            {
                Console.WriteLine("Value is not available in collection");
            }

        }
        static void DisplayRecords_Hashtable()
        {

            foreach (DictionaryEntry objDE in objHashtable)
            {
                Console.WriteLine("Key:" + objDE.Key + "Value:" + objDE.Value);
            }

        }
        static void CountRecords_Hashtable()
        {

            int count;
            count = objHashtable.Count;
            Console.WriteLine("Count of RTO Detail Collections:" + count);
        }
        static void RemoveRecord_Hashtable()
        {
            Console.WriteLine("Enter key to remove from RTO Details collection:");
            string key = Console.ReadLine();
            objHashtable.Remove(key);
            Console.WriteLine("Removed record from RTO Details collection:");

        }
    }
}
