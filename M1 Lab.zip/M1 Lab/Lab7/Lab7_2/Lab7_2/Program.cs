﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Lab7_2
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Product[] p;
            // Product p1 = new Product();
            ArrayList objal = new ArrayList();
            int choice;
            //add(); Search();
            do
            {
                Console.WriteLine("\n-------------------------------------------------------\nPress the following Keys to proceed :\n 1-->Add product \n 2-->Search product " +
                    "\n 3-->Delete product\n 4-->Save in sorted order\n 5---> Quit");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        {
                            add();
                            break;
                        }
                    case 2:
                        {
                            Search();
                            break;
                        }
                    case 3:
                        {
                            Delete();
                            //Console.WriteLine("delete");
                            break;
                        }
                    case 4:
                        {
                            SaveInSorted();
                            break;
                        }

                    case 5:
                        break;
                    default:
                        Console.WriteLine("Please enter valid input");
                        break;

                }
            } while (choice != 5);

            //int count;

            void add()
            {
                Console.WriteLine("Enter the number of product you wish to Enter:");
                int numproduct = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < numproduct; i++)
                {
                    Product objProduct = new Product();
                    Console.WriteLine("Product Number : ");
                    objProduct.prodno = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Product Name : ");
                    objProduct.name = Console.ReadLine();
                    Console.WriteLine(" Product Rating : ");
                    objProduct.rate = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Product Stock : ");
                    objProduct.stock = Convert.ToInt32(Console.ReadLine());
                    objal.Add(objProduct);
                    // objal.Add(p1);
                    Console.WriteLine(" -----------Data entered successfully----------");
                }
                //count++;

            }
            void Search()
            {
                int check;
                Console.WriteLine("\n---------------------------------------------\nEnter product number u want to Search");
                check = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < objal.Count; i++)
                {
                    Product objProduct = objal[i] as Product;
                    //
                    if (objProduct.prodno == check)
                    {
                        Console.WriteLine("Ur record is PRESENT\n-----------------------------\n");

                        Console.WriteLine("Product Number :  " + objProduct.prodno + "\nProduct Name :   " + objProduct.name + "\nProduct Rating :  " + objProduct.rate + "\nProduct Stock :  " + objProduct.stock);
                    }

                    else
                    {
                        Console.WriteLine("Ur record is ABSENT");
                    }

                }


            }
            void Delete()
            {
                int check;
                Console.WriteLine("\n---------------------------------------------\nEnter product number u want to delete");
                check = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < objal.Count; i++)
                {
                    Product objProduct = objal[i] as Product;
                    //
                    if (objProduct.prodno == check)
                    {
                        objal.Remove(objProduct);




                        Console.WriteLine(" -----------Data removed successfully----------");

                    }
                }



            }
            void SaveInSorted()
            {
                /* foreach (var obj in objal)
                 {
                     Console.WriteLine(obj);
                     Console.WriteLine("Product Number :  " + p1.prodno + "\nProduct Name :   " + p1.name + "\nProduct Rating :  " + p1.rate + "\nProduct Stock :  " + p1.stock);
                 }*/

                for (int i = 0; i < objal.Count; i++)
                {
                    Product objProduct = objal[i] as Product;
                    // objal.Sort();
                    objal.Sort();
                    Console.WriteLine("Product Number :  " + objProduct.prodno + "\nProduct Name :   " + objProduct.name + "\nProduct Rating :  " + objProduct.rate + "\nProduct Stock :  " + objProduct.stock);
                    Console.WriteLine("-----------------------------------------------------");
                }

                Console.ReadKey();
            }
        }

    }
}
