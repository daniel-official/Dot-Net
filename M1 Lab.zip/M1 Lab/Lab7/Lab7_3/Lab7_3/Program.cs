﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;

namespace Lab7_3
{
    class Program
    {
        public static List<Employee> employees = new List<Employee>();
        static void Main(string[] args)
        {

            Console.WriteLine("ENTER DETAILS");
            Console.WriteLine("-------------");

            get_details();
            display();
            
        }

        public static void get_details()
        {
            Employee emp = new Employee();
            Console.Write("Employee Number: ");

            emp.Employee_Number = Convert.ToInt32(Console.ReadLine());
            Console.Write("Employee Name: ");

            emp.E_Name = Console.ReadLine();
            Console.Write("Basic Salary of The Employee: ");
            emp.Basic_Salary = Convert.ToDouble(Console.ReadLine());
            Console.Write("PF: ");
            emp.E_PF = Convert.ToDouble(Console.ReadLine());
            Console.Write("Input taken");
            employees.Add(emp);
            Console.WriteLine("passed to list");

            // display();


        }

        public static void display()
        {
            Console.WriteLine("_______________________");
            Console.WriteLine("ENTERED IN DISPLAY FUNC");
            foreach (Employee e in employees)
            {
                Console.WriteLine("\nEmployee No: {0},\nEmployee Name: {1}, \nBasic Salary: {2}, \nPF: {3}", e.Employee_Number, e.E_Name, e.Basic_Salary, e.E_PF);
            }

        }
    }
}
