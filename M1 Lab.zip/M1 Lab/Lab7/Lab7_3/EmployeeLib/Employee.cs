﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class Employee
    {

        public int Employee_Number { get; set; }
        public string E_Name { get; set; }
        public double Basic_Salary { get; set; }
        public double E_PF { get; set; }

        public Employee()
        {

        }
        public Employee(int eno, string ename, double bsal, double pf)
        {
            Employee_Number = eno;
            E_Name = ename;
            Basic_Salary = bsal;
            E_PF = pf;
        }

    }
}
