﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    abstract class Program //: EmployeeLib.Employee
    {
        public abstract double GetSalary();
        static void Main(string[] args)
        {
            ContractEmployee objCE = new ContractEmployee();
            PermanentEmployee objPE = new PermanentEmployee();

            Console.WriteLine("Choose 1 for Contract Employee");
            Console.WriteLine("Choose 2 for Permanent Employee");
            int c;
            c = Convert.ToInt32(Console.ReadLine());
            switch (c)
            {
                case 1:
                    GetDetails();
                    double sal = objCE.GetSalary();
                    Console.WriteLine("Salary of Contract Employee is :" + sal);
                    break;

                case 2:
                    GetDetails();
                    double sal1 = objPE.GetSalary();
                    Console.WriteLine("Salary of Permanent Employee is :" + sal1);
                    break;

                default:
                    break;
            }

        }

        static void GetDetails()
        {
            Console.WriteLine("Enter Employee ID :");
            double empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the name of Employee :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Address :");
            string address = Console.ReadLine();
            Console.WriteLine("Enter the city :");
            string city = Console.ReadLine();
            Console.WriteLine("Enter the Department of Employee :");
            string department = Console.ReadLine();

        }
    }
}
