﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    class PermanentEmployee : EmployeeLib.Employee
    {
        public int NoOfLeaves { get; set; }
        public double ProvidendFund { get; set; }

        public override double GetSalary()
        {
            Console.WriteLine("Enter the Salary of Employee");
            Salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter No of Leave :");
            NoOfLeaves = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Providend Fund :");
            ProvidendFund = Convert.ToInt32(Console.ReadLine());
            double result;
            result = Salary - ProvidendFund;
            return result;

        }

    }
}
