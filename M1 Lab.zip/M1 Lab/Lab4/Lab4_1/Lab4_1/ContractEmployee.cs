﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    class ContractEmployee : EmployeeLib.Employee
    {
        public double Perks { get; set; }

        public override double GetSalary()
        {
            Console.WriteLine("Enter the Salary of Employee");
            Salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Perks:");
            Perks = Convert.ToInt32(Console.ReadLine());
            double result;
            result = Salary + Perks;
            return result;
        }
    }
}
