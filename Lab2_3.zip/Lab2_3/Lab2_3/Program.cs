﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_3
{
    class Program
    {
        static string[] names = new string[3];
        static void Main(string[] args)
        {
            GetNames();
            DisplayNames();
            Console.ReadKey();

        }

        static void GetNames() {
            Console.WriteLine("------Getting the Names of the Cities------");
            Console.WriteLine("Enter the name of the city:");
            for (int i = 0; i < names.Length; i++) { 
                names[i] = Convert.ToString(Console.ReadLine());
            }
        }

        static void DisplayNames(){
            Console.WriteLine("------Displaying the Cities------");
            foreach (string name in names) {
                Console.WriteLine(name);
            }
        }

    }
}

