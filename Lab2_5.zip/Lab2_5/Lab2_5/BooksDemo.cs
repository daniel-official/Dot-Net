﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_5
{
    class BooksDemo
    {
        string[,] books = new string[1, 4];

        public void GetDetails() {
            for(int i=0;i<books.GetLength(0);i++) {
                int flag = 0;
                Console.WriteLine("-----Getting Book Details-----");
                do {
                    Console.WriteLine("Book Title:");
                    books[i, 0] = Console.ReadLine();
                    Console.WriteLine("Author:");
                    books[i, 1] = Console.ReadLine();
                    Console.WriteLine("Publisher:");
                    books[i, 2] = Console.ReadLine();
                    Console.WriteLine("Price:");
                    books[i, 3] = Console.ReadLine();
                    flag = 1;
                } while (flag==0);
            }
        }

        public void DisplayDetails() {
            for (int i=0;i<books.GetLength(0);i++) {
                int flag;
                Console.WriteLine("-----Displaying Book Details-----");
                do
                {
                    Console.WriteLine("Title:" + books[i,0]);
                    Console.WriteLine("Author:"+books[i,1]);
                    Console.WriteLine("Publisher:" + books[i, 2]);
                    Console.WriteLine("Price:" + books[i, 3]);
                    flag = 1;
                } while (flag==0);
            }
            }

    }
}
