﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary6;

namespace l7q3
{
    class Program
    {
        public static  List<Employee> employees = new List<Employee>();
        static void Main(string[] args)
        {
            
            Console.WriteLine("enter details to be added to the list:-");
            
           get_details();
           display();
            Console.WriteLine("press any key to exit...");
            Console.ReadLine();
        }

        public static void get_details()
        {
            Employee emp = new Employee();
            Console.WriteLine("enter the employee number:");

            emp.Employee_Number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the employee name:");

            emp.E_Name = Console.ReadLine();
            Console.WriteLine("enter the basic salary of the employee:");
            emp.Basic_Salary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter the amount of the employee PF:");
            emp.E_PF = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Input taken");
            employees.Add(emp);
            Console.WriteLine("passed to list");

           // display();


        }

        public static void display()
        {
            Console.WriteLine("ENTERED IN DISPLAY FUNC");
            foreach (Employee e in employees)
            {
                Console.WriteLine("Employee No: {0}, Name: {1}, Basic Salary: {2}, PF: {3}", e.Employee_Number, e.E_Name, e.Basic_Salary, e.E_PF);
            }

        }
    }
}
