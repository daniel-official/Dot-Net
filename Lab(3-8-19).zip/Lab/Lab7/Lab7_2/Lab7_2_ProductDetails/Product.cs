﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7_2_ProductDetails
{
    class Product
    {
        public int prodno;
        public string name;
        public int rate;
        public int stock;

       
    }
}
