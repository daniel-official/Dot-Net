﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lab12_1
{
    class Program
    {
        static void Main(string[] args)
        {

            DisplayFile();
        }

        static void DisplayFile() {
            try
            {
                Console.WriteLine("Enter the name of the file with extension:");
                string strFileName = @"D:\dgyanapr\Lab\Lab12_1\"+Console.ReadLine();
                FileStream objFS = new FileStream(strFileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            
            StreamReader objSR = new StreamReader(objFS);
                string StrDataFromFile = objSR.ReadLine();
                objSR.Close();
                objFS.Close();
                Console.WriteLine("----------------------------");
                Console.WriteLine("Date from File : " + StrDataFromFile);
            }
            catch (Exception e)
            {
                Console.WriteLine("File Does Not Found");
            }

        }
    }
}
