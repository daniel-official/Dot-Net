﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    class Supplier
    {
        int id;
        string name;
        string city;
        int phoneNo;
        string emailId;

        public void AcceptDetails() {
            Console.WriteLine("---Get Details---");
            Console.WriteLine("Id:");
            id=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name:");
            name=Console.ReadLine();
            Console.WriteLine("City:");
            city=Console.ReadLine();
            Console.WriteLine("Phone No:");
            phoneNo=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Email Id");
            emailId=Console.ReadLine();
        }

        public void DisplayDetails() {
            Console.WriteLine("---Display Details---"  );
            Console.WriteLine("Id:"+id);
            Console.WriteLine("Name:" +name );
            Console.WriteLine("City:" +city );
            Console.WriteLine("phoneNo No:" +phoneNo );
            Console.WriteLine("Email Id:" +emailId );

        }
    }
}
