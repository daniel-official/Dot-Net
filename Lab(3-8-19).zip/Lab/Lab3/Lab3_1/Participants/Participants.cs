﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParticipantsLib
{
    public class Participants
    {
        int empId;
        string name;
        static string companyName;
        double foundationMarks;
        double webBasicMarks;
        double dotNetMarks;
        double totalMarks;
        double obtainedMarks;
        double percentage;
        //
        StringBuilder objSB = new StringBuilder();
        bool isValid = true;

        public int EmpId
        {
            get
            {
                return empId;
            }
            set
            {
                empId = value;
            }
        }

        public string Name { get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string CompanyName
        {
            get
            {
                return companyName;
            }
            set
            {
                companyName = value;
            }
        }

        public double FoundationMarks
        {
            get
            {

                return foundationMarks;
            }
            set
            {
                
                foundationMarks = value;
                Validation();
            }
        }

        public double WebBasicMarks {
            get
            {
                return webBasicMarks;
            }
            set
            {
                
                webBasicMarks = value;
                Validation();
            }
        }

        public double DotNetMarks {
            get
            {
                return dotNetMarks;
            }
            set
            {
                
                dotNetMarks = value;
                Validation();
            }
        }

        public double TotalMarks
        {
            get
            {
                return totalMarks;
            }
            set
            {
                totalMarks = value;
            }
        }

        public double ObtainedMarks
        {
            get
            {
                return obtainedMarks;
            }
            set
            {
                obtainedMarks = value;
            }
        }

        public double Percentage
        {
            get
            {
                return percentage;
            }
            set
            {
                percentage = value;
            }
        }

        public Participants()
        {
            //Default constructor
        }
        
        public Participants(int strEmpId, string strName, double strFoundationMarks, double strWebBasicMarks, double strDotNetMarks)
        {
            this.EmpId = strEmpId;
            this.Name = strName;
            this.FoundationMarks = strFoundationMarks;
            this.WebBasicMarks = strWebBasicMarks;
            this.DotNetMarks = strDotNetMarks;
            this.TotalMarks = 300;
        }

        public void Validation()
        {

            if(FoundationMarks < 0 || FoundationMarks > 100 )
            {
                objSB.Append("Foundation Marks must be greater than 0 and less than 100.");
                isValid = false;
            }
            if (WebBasicMarks < 0 || WebBasicMarks > 100)
            {
                objSB.Append("WebBasics Marks must be greater than 0 and less than 100.");
                isValid = false;
            }
            if (DotNetMarks < 0 || DotNetMarks > 100)
            {
                objSB.Append("DotNet Marks must be greater than 0 and less than 100.");
                isValid = false;
            }
            if(isValid == false)
            {
                throw new Exception(objSB.ToString());
            }
        }

        static Participants( )
        {
            companyName = "Corporate University";
        }

        public void CalculateTotalMarks()
        {
            ObtainedMarks= FoundationMarks + WebBasicMarks + DotNetMarks;
        }

        public void CalculatePercenatge()
        {
            Percentage = (ObtainedMarks/TotalMarks) * 100 ;

        }
    }
}
