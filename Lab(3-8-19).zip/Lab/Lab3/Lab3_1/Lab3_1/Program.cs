﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

            Console.WriteLine("---Enter the Details---");
            Console.WriteLine("ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name:");
            string name=Console.ReadLine();
            Console.WriteLine("Foundation:");
            double foundMarks = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("WebBasic:");
            double webMarks = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Dotnet:");
            double DotMarks = Convert.ToDouble(Console.ReadLine());

            ParticipantsLib.Participants objParticipants = new ParticipantsLib.Participants(id,name,foundMarks,webMarks,DotMarks);

            objParticipants.CalculateTotalMarks();
            objParticipants.CalculatePercenatge();
            Console.WriteLine("Percentage : " + objParticipants.Percentage);

            }
            catch(Exception objEx)
            {
                Console.WriteLine(objEx.Message);
            }

        }
    }
}
