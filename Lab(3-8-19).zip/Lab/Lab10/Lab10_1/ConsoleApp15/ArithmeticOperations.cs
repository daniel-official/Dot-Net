﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10Q1
{
    internal class ArithmeticOperations
    {
        delegate int ArithmeticOperationHandler(int num1, int num2);
        static void Main(string[] args)
        {
            Calculator obj = new Calculator();
            Console.WriteLine("enter the two numbers:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int num2 = Convert.ToInt32(Console.ReadLine());
            //UNICASTING DELEGATES
            ArithmeticOperationHandler objAOH = new ArithmeticOperationHandler(obj.Addition); 
            int result = objAOH.Invoke(num1, num2);
            Console.WriteLine("output of addition=" + result);
            ArithmeticOperationHandler objAOH2 = new ArithmeticOperationHandler(obj.Subtraction);
            int result2 = objAOH2.Invoke(num1, num2);
            Console.WriteLine("output of subtraction=" + result2); ArithmeticOperationHandler objAOH3 = new ArithmeticOperationHandler(obj.Multiplication);
            int result3 = objAOH3.Invoke(num1, num2);
            Console.WriteLine("output of multiplication=" + result3);
            ArithmeticOperationHandler objAOH4 = new ArithmeticOperationHandler(obj.Division);
            int result4 = objAOH4.Invoke(num1, num2);
            Console.WriteLine("output of division=" + result4);
            ArithmeticOperationHandler objAOH5 = new ArithmeticOperationHandler(obj.Findmax);
            int result5 = objAOH5.Invoke(num1, num2);
            Console.WriteLine("output of max=" + result5);
            Console.ReadKey();

        }
    }
}
