﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10Q1
{
    internal class Calculator
    {
        internal int Addition(int num1, int num2)
        {
            int sum = num1 + num2;
            return sum;
        }
        internal int Subtraction(int num1, int num2)
        {
            int sub = num1 - num2;
            return sub;
        }
        internal int Multiplication(int num1, int num2)
        {
            int mul = num1 * num2;
            return mul;
        }
        internal int Division(int num1, int num2)
        {
            int div = num1 / num2;
            return div;
        }
        internal int Findmax(int num1, int num2)
        {
            return Math.Max(num1,num2);
        }
    }
}
