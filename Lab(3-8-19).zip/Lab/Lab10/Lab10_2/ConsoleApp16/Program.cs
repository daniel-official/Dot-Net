﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l10q2
{
    public delegate int ArithmeticOperationHandler(int num1, int num2);
    internal class ArithmeticOperations
    {
        static void Main(string[] args)
        {
            ArithmeticOperations obj = new ArithmeticOperations();
            Console.WriteLine("enter the two numbers:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int num2 = Convert.ToInt32(Console.ReadLine());

            //anonymous delegate
            ArithmeticOperationHandler objAOHadd = delegate (int n1, int n2)
            {
                int res;
                res = num1 + num2;
                return res;
            };
            int resultAddition = PerformArithmeticOperation(num1, num2, objAOHadd);
            Console.WriteLine("Addition is: " + resultAddition);
            
            ArithmeticOperationHandler objAOHsub = delegate (int n1, int n2)
            {
                int res;
                res = num1 - num2;
                
                return res;
            };
            int resultSubtraction = PerformArithmeticOperation(num1, num2, objAOHsub);
            Console.WriteLine("Subtraction is: " + resultSubtraction);

            ArithmeticOperationHandler objAOHmul = delegate (int n1, int n2)
            {
                int res;
                res = num1 * num2;
                return res;
            };
            int resultMultiplication = PerformArithmeticOperation(num1, num2, objAOHmul);
            Console.WriteLine("Multiplication is: " + resultMultiplication);

            ArithmeticOperationHandler objAOHdiv = delegate (int n1, int n2)
            {
                int res;
                res = num1 / num2;
                return res;
            };
            int resultDivision = PerformArithmeticOperation(num1, num2, objAOHdiv);
            Console.WriteLine("division is: " + resultDivision);

            ArithmeticOperationHandler objAOHmax = delegate (int n1, int n2)
            {
                int res = Math.Max(num1, num2);
                return res;
            };
            int resultmax = PerformArithmeticOperation(num1, num2, objAOHmax);
            Console.WriteLine("Max number is: " + resultmax);
            
            Console.ReadKey();

        }
        internal static int PerformArithmeticOperation(int n1, int n2, ArithmeticOperationHandler objAOH)
        {
            int result = objAOH(n1, n2);
            return result;
        }
    }
}
