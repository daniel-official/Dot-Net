﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab11Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            CreditCard cc = new CreditCard(10, "Nishant");
            cc.makePayment+= new CreditHandler(GetNotification);
            cc.MakePayment(85000);
        }
        static void GetNotification()
        {
            Console.WriteLine("Amount Is Debited Transaction Successful...");
        }
    }
}
