﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_4
{
    public class Program
    {
        
        static void Main(string[] args)
        {
            char opt;
            ProdecutDemo objProduct = new ProdecutDemo();
            //Boxing
            do 
                    {
                
                Console.WriteLine("---Getting Details From User---");
                Console.WriteLine("product Id:");
                objProduct.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("product Name:");
                objProduct.ProductName = Console.ReadLine();
                Console.WriteLine("product price:");
                objProduct.Price = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Quantity :");
                objProduct.Quantity = Convert.ToInt32(Console.ReadLine());

                //Unboxing

                int id = (int)objProduct.ProductId;
                string name = objProduct.ProductName as string;
                int price = (int)objProduct.Price;
                int quantity = (int)objProduct.Quantity;
                double amount = price * quantity;
                objProduct.AmountPayable = amount;

                Console.WriteLine("product Id:" + id);
                Console.WriteLine("product Name:" + name);
                Console.WriteLine("product price:" + price);
                Console.WriteLine("Quantity :" + quantity);
                Console.WriteLine("Amount Payable: " + amount);

                Console.WriteLine("Do you want to continue(y/n): ");
                opt = Convert.ToChar(Console.ReadLine());
            }while (opt=='y') ;
            Console.ReadKey();
        }
        
    }
}
