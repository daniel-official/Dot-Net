﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_5
{
    class Program
    {
        static void Main(string[] args)
        {
            BooksDemo objBook = new BooksDemo();
            char opt;
            do
            {
                objBook.GetDetails();
                objBook.DisplayDetails();

                Console.WriteLine("Do you want to continue(y/n):");
                opt=Convert.ToChar( Console.ReadLine());
                //Console.ReadKey();
            } while (opt=='y');
        }
    }
}
