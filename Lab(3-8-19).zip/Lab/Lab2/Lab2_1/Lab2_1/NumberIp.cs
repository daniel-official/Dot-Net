﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_1
{
    struct NumberIp
    {
        public int number;

        public NumberIp(int num)
        {
            number = num;
        }

        public int Suqare()
        {
            int result;
            result = number * number;
            return result;
        }

        public int Cube()
        {
            int result;
            result = number * number * number;
            return result;
        }
    }
}
