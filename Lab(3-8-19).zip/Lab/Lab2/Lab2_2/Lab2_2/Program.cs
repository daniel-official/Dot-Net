﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_2
{
    class Program
    {
        static int[,] numbers = new int[2,3];
        static void Main(string[] args)
        {
            GetDetails();

            DisplayDetails();
            
            Console.ReadKey();
        }

        static void GetDetails() {

            Console.WriteLine("-----Getting values from uesr-----");
            for (int i=0;i<numbers.GetLength(0);i++) {
                Console.WriteLine("Enter values for Row "+i);
                for (int j = 0; j < numbers.GetLength(1); j++) {
                   numbers[i,j]=Convert.ToInt32( Console.ReadLine());
                }
            }


        }

        static void DisplayDetails()
        {
            Console.WriteLine("-----Dissplaying the numbers in array format-----");

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write(numbers[i,j]+" ");
                }
                Console.WriteLine();
            }
        }

    }


}
