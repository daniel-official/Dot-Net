﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTOAPP
{
    class Customer
    {

        static void Main(string[] args)
        {
            try
            {
                Customer1 obj = new Customer1(100, "AB", "CD", "EF", "9999999999", 1000000);
                

            }
             catch(InvalidCreditLimitException i)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
