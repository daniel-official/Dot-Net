﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;

namespace Lab4_1
{
    public class PermanentEmployee : Employee
    {
       
        int noOfLeaves;
        public int NoOfLeaves
        {
            set
            {
                noOfLeaves = value;
            }
            get
            {
                return noOfLeaves;
            }
        }
        int providentFund;
        public int ProvidentFund
        {
            set
            {
                providentFund = value;
            }
            get
            {
                return providentFund;
            }
        }

        public override int GetSalary() {

            Console.WriteLine("Enter the Salary:");
            Salary = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Pf:");
            ProvidentFund = int.Parse(Console.ReadLine());
            Salary = Salary - ProvidentFund;
            return (Salary);
        }

    }
}
