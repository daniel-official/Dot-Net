﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1--Contract Employee.");
            Console.WriteLine("2--Permenant Employee.");
            int choice=int.Parse(Console.ReadLine());
            switch (choice) {
                case 1:
                    ContractEmployee objCE = new ContractEmployee();
                    objCE.GetSalary();
                    Console.WriteLine ("The Final salary is : "+objCE.Salary);
                    break;
                case 2:
                    PermanentEmployee objPE = new PermanentEmployee();
                    objPE.GetSalary();
                    Console.WriteLine("The Final salary is : " + objPE.Salary);
                    break;
            }
        }
    }
}
