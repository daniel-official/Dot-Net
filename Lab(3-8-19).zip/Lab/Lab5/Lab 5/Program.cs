﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankAccount;

namespace Lab_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //ICICI BANK
            Console.WriteLine("==========================ICICI================================ ");
            Console.WriteLine("After Deposit");

            BankAccount.ICICI i1 = new BankAccount.ICICI();            
            i1.AccountType(BankAccountTypeEnum.Saving);
            i1.Deposit(50000);

            ICICI i2 = new ICICI();
            i2.AccountType(BankAccountTypeEnum.Current);
            i2.Deposit(20000);

            Console.WriteLine("Your Saving Account = " + i1.GetBalance());
            Console.WriteLine("Your Current Account = " + i2.GetBalance());
            i1.CalculateInterest();
            i2.CalculateInterest();
            
            //Transfer
            i1.Transfer(i2, 5000);           

            Console.WriteLine("After Transfer");

            Console.WriteLine("Your Savings Account = " + i1.GetBalance());
            Console.WriteLine("Your Current Account = " + i2.GetBalance());
            i1.CalculateInterest();
            i2.CalculateInterest();
            
            
            //HSBC ACCOUNT
            Console.WriteLine("==========================HSBC================================ ");
            Console.WriteLine("After Deposit");

            BankAccount.HSBC h1 = new BankAccount.HSBC();
            h1.AccountType(BankAccountTypeEnum.Saving);
            h1.Deposit(50000);

            HSBC h2 = new HSBC();
            h2.AccountType(BankAccountTypeEnum.Saving);
            h2.Deposit(20000);

            Console.WriteLine("Your Savings Account = " + h1.GetBalance());
            Console.WriteLine("Your Current Account = " + h2.GetBalance());
            h1.CalculateInterest();
            h2.CalculateInterest();

            //transfer
            h1.Transfer(h2, 30000);


            Console.WriteLine("After Transfer");

            Console.WriteLine("Your Savings Account = " + h1.GetBalance());
            Console.WriteLine("Your Current Account = " + h2.GetBalance());
            h1.CalculateInterest();
            h2.CalculateInterest();




            Console.ReadKey();

        }
    }
}
