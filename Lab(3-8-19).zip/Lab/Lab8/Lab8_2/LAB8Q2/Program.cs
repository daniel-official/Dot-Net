﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace LAB8Q2
{
    class Program
    {
         
        static void Main(string[] args)
        {
            Hashtable objHash = new Hashtable();
            objHash = GetHashtable();
            // string key = "Perimeter";
            Console.WriteLine("\nContains Key:");
            Console.WriteLine(objHash.ContainsKey("Perimeter"));


            bool flag = objHash.ContainsKey("Area");
            if (flag == true)
            {
                int value = (int)objHash["Area"];
                Console.WriteLine("Value of Area:" + value);
            }
        
            Console.WriteLine("\nContains Demo:");

            objHash.Remove("Mortgage");
            Console.WriteLine("\nMortagage removed from Hashtable.");
            foreach(DictionaryEntry objDE in objHash)
            {
                Console.WriteLine("key" + objDE.Key + "value" + objDE.Value);
            }
            Console.ReadLine();
        }


        public  static Hashtable GetHashtable()
        {
            // Create and return new Hashtable.
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            return hashtable;
        }


    }
}
