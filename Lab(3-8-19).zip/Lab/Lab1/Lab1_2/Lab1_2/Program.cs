﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double operation;
            double fnum;
            double snum;
            double result;
            char opt;

            do
            {
                Console.WriteLine("Enter the first number:");
                fnum = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter the second number:");
                snum = Convert.ToDouble(Console.ReadLine());



                Console.WriteLine("Enter 1 for addition");
                Console.WriteLine("Enter 2 for subtraction");
                Console.WriteLine("Enter 3 for multiplication");
                Console.WriteLine("Enter 4 for division");
                Console.WriteLine("Enter 5 for Modules");


                operation = Convert.ToDouble(Console.ReadLine());
                //Calculator objCalculator = new Calculator(); 
                ArithmeticOperations.Calculator objCalculator = new ArithmeticOperations.Calculator();

                switch (operation)
                {
                    case 1:
                        //addition

                        result = objCalculator.Addition(fnum, snum);
                        Console.WriteLine("addition of two number is:" + result);
                        break;
                    case 2:
                        //subtraction

                        result = objCalculator.Subtraction(fnum, snum);
                        Console.WriteLine("Subtraction of two number is:" + result);
                        break;
                    case 3:
                        //multiplication

                        result = objCalculator.Multiplication(fnum, snum);
                        Console.WriteLine("MUltiplication of two number is:" + result);
                        break;
                    case 4:
                        //division

                        result = objCalculator.Division(fnum, snum);
                        Console.WriteLine("Division of two number is:" + result);
                        break;
                    case 5:
                        //Modules

                        result = objCalculator.Modules(fnum, snum);
                        Console.WriteLine("Modules of two number is:" + result);
                        break;
                    default:
                        Environment.Exit(0);
                        break;

                }
                Console.WriteLine("Do u want to continue(y/n):");
                opt = Convert.ToChar(Console.ReadLine());

                //Console.ReadLine();
            } while (opt == 'y');
        }
    }
}
