﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_4
{
    class SchoolDemo
    {
        static void Main(string[] args)
        {
            int rno;
            string stdname;
            byte age;
            char gender;
            DateTime dob;
            string address;
            float percentage;

            Console.WriteLine("---Taking input from user---");
            Console.WriteLine("_____________________________");
            Console.WriteLine("RollNumber:");
            rno=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Student Name:");
            stdname = Convert.ToString (Console.ReadLine());

            Console.WriteLine("Age: ");
            age = Convert.ToByte (Console.ReadLine());

            Console.WriteLine("Gender:");
            gender = Convert.ToChar (Console.ReadLine());

            Console.WriteLine("Date Of Birth:");
            dob = Convert.ToDateTime (Console.ReadLine());

            Console.WriteLine("Address:");
            address = Convert.ToString (Console.ReadLine());

            Console.WriteLine("Percentage;");
            percentage = Convert.ToInt64 (Console.ReadLine());


            Console.WriteLine("Displaying Details");
            Console.WriteLine("____________________");
            Console.WriteLine("Student RollNumber:" + rno);
            Console.WriteLine("Student Name:" + stdname);
            Console.WriteLine("Student Age:" + age);
            Console.WriteLine("Student Gender:" + gender);
            Console.WriteLine("Student Date of Birth:" + dob);
            Console.WriteLine("Student Address:" + address);
            Console.WriteLine("Student Percentage:" + percentage);
            Console.ReadKey();
        }
    }
}
