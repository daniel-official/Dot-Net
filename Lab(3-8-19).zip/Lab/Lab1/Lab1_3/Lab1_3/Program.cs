﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int opt;
            char choice;
            
            do
            {
                Console.WriteLine("Enter a number:");
                opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.WriteLine("You just pressed the number 1");
                        break;
                    case 2:
                        Console.WriteLine("You just pressed the number 2");
                        break;
                    case 3:
                        Console.WriteLine("You just pressed the number 3");
                        break;
                    case 4:
                        Console.WriteLine("You just pressed the number 4");
                        break;
                    case 5:
                        Console.WriteLine("You just pressed the number 5");
                        break;
                    default:
                        Console.WriteLine("Please press a valid number");
                        break;

                }
                Console.WriteLine("__________________________________________");
                Console.WriteLine("Do you want to continue(y/n):");
                choice=Convert.ToChar(Console.ReadLine());
            } while (choice == 'y'); 
            //Console.ReadKey();

        }
    }
}
