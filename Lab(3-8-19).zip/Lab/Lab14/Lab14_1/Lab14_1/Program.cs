﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuestPhoneBookBusinessLayer;
using GuestPhoneBookEntities;
using GuestPhoneBookExceptions;

namespace GuestPhoneBookPresentationLayer
{
    class Program
    {

        public static int option;
        public static void Main(string[] args)
        {

            do
            {
                menu();
                OpAction(option);
            } while (option<6);
        }

        static void menu() {
            List<string> liMenu = new List<string>() { "1-Add Guest", "2-Delete Guest", "3-Update Guest", "4-Search Guest", "5-List All Guest", "6-Exit" };
            Console.WriteLine("--------------------------");
            Console.WriteLine("_____GUEST PHONE BOOK_____\n");
            
            foreach (var menu in liMenu) {
                Console.Write(""+menu+"\n");
            }
            Console.Write("Enter The Option:");
            option = int.Parse(Console.ReadLine());
            



        }

        public static void OpAction(int option)
        {
            switch (option) {
                case 1:
                    Console.Clear();
                    AddGuest(); 
                    
                    break;
                case 2:
                    Console.Clear();
                    DeleteGuest();
                    
                    break;
                case 3:
                    Console.Clear();
                    UpdateGuest();
                    
                    break;
                case 4:
                    Console.Clear();
                    SearchGuest();
                   
                    break;
                case 5:
                    Console.Clear();
                    ListAllGuest();
                    
                    break;
                case 6:
                    return;
                    
                
            }

        }


        public static void AddGuest() {
            ClassEL AddGuest = new ClassEL();
            Console.WriteLine("----------------");
            Console.WriteLine("Add a New guest");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter a Id:");
            AddGuest.ID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Name:");
            AddGuest.Name = Console.ReadLine();
            Console.WriteLine("Enter a Phone number:");
            AddGuest.PhoneNo = Console.ReadLine();

            bool guestadded=Convert.ToBoolean( ClassBL.AddGuest(AddGuest));

            if (guestadded == true)
                Console.WriteLine("Guest Added");
            else
                Console.WriteLine("Could not Add Guest !!");
        }

        static void UpdateGuest()
        {
            ClassEL UpdateGuest = new ClassEL();
            Console.WriteLine("----------------");
            Console.WriteLine("Updete the Details of a Existing Guest");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter The Guest Id:");
            UpdateGuest.ID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Name:");
            UpdateGuest.Name = Console.ReadLine();
            Console.WriteLine("Enter a Phone number:");
            UpdateGuest.PhoneNo = Console.ReadLine();
            bool GuestUpdated = ClassBL.UpdateGuest(UpdateGuest);

            if (GuestUpdated == true)
                Console.WriteLine("Guest Details Updated");
            else
                Console.WriteLine("Could Not Updated the Details of Guest !!");

        }

        static void SearchGuest()
        {
            Console.WriteLine("----------------");
            Console.WriteLine("Search Guest");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter the Guest Id:");
            int SearchGuestId=int.Parse(Console.ReadLine());
            ClassEL SearchGuest = ClassBL.SearchGuest(SearchGuestId);

            Console.WriteLine("Id: " +SearchGuest.ID);
            Console.WriteLine("Name: " + SearchGuest.Name);
            Console.WriteLine("Phone Number : " + SearchGuest.PhoneNo);

        }

        public static void ListAllGuest()
        {
            List<ClassEL> GuestList= ClassBL.ListallGuest();
            Console.WriteLine("Guest Details");
            Console.WriteLine("---------------------------");
            Console.WriteLine("Id \tName\tPhone Number");
            Console.WriteLine("---------------------------");
            foreach (ClassEL guest in GuestList)
            {
                
                Console.WriteLine(  guest.ID +"\t"+ guest.Name+"\t"+ guest.PhoneNo);
                
            }

        }

        static void DeleteGuest()
        {
            Console.WriteLine("----------------");
            Console.WriteLine("Deleting Guest");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter the Id: ");
            int deleteGuestId= int.Parse(Console.ReadLine());

            bool guestUpdated= ClassBL.RemoveGuest(deleteGuestId);

            if (guestUpdated == true)
                Console.WriteLine("Guest Deleteed");
            else
                Console.WriteLine("Could not Delete Guest");
        }
    }
}
