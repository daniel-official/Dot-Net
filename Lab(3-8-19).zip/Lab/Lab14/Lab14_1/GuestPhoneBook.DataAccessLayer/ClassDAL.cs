﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuestPhoneBookEntities;
using GuestPhoneBookExceptions;


namespace GuestPhoneBookDataAccessLayer
{
    public class ClassDAL
    {
        public static List<ClassEL> guestList = new List<ClassEL>();

        public static bool AddGuest(ClassEL AddGuest)
        {
            bool guestAdded = false;
            guestList.Add(AddGuest);
            guestAdded = true;
            return guestAdded;
        }

        public static List<ClassEL> ListallGuest()
        {

            return guestList;
        }

        public static ClassEL SearchGuest(int SearchGuestId)
        {
            ClassEL SearchGuest = new ClassEL();
            SearchGuest = guestList.Find(guest => guest.ID == SearchGuestId);

            return SearchGuest;
        }

        public static bool UpdateGuest(ClassEL UpdateGuest)
        {
            bool GuestUpdated=false;

            ClassEL Guest = guestList.Find(guest =>guest.ID==UpdateGuest.ID);
            Guest.Name = UpdateGuest.Name;
            Guest.PhoneNo = UpdateGuest.PhoneNo;
            GuestUpdated = true;
            return GuestUpdated;
        }

        public static bool RemoveGuest(int UpdateGuestId)
        {
            bool guestRemoved = false;

            ClassEL UpdateGuest = guestList.Find(Guest =>Guest.ID==UpdateGuestId);
            if (UpdateGuest != null)
            {
                guestList.Remove(UpdateGuest);
                guestRemoved = true;
            }
            return guestRemoved;
        }
    }
}
