﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace LAB13_Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            Contact contact1 = new Contact();
            Console.WriteLine("Enter Contact No:");
            contact1.ContactNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Contact Name:");
            contact1.ContactName = Console.ReadLine();
            Console.WriteLine("Enter Cell no:");
            contact1.CellNo = Console.ReadLine();
       
            try
            {
                FileStream objFS = new FileStream(@"D:\SoapSerialization.xml", FileMode.Create, FileAccess.Write, FileShare.Read);
                SoapFormatter objSoapF = new SoapFormatter();
                objSoapF.Serialize(objFS, contact1);
                objFS.Close();
                Console.WriteLine("Record Inserted");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



            // =============== Deserialization ============

            List<Contact> objNewCon = new List<Contact>();
            try
            {
                FileStream objFS = new FileStream(@"D:\SoapSerialization.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
                SoapFormatter Soap = new SoapFormatter();
                objNewCon = (List<Contact>)Soap.Deserialize(objFS) ;
                objFS.Close();
                Console.WriteLine("-----------------Soap DeSerialization--------------");
                Console.WriteLine("-- Employee Detail--");
                foreach (Contact c in objNewCon)
                {
                    Console.WriteLine("Contact No:{0}\tContact Name:{1}\tCell no:{2}", c.ContactNo, c.ContactName, c.CellNo);
                }
                //Console.WriteLine("Contact NO : {0},  Contact NAME: {1},   Cell no: {2}", objNewCon.ContactNo, objNewCon.ContactName, objNewCon.CellNo);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }






        }
    }
}
