﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace LAB13_Q6
{
    class Program
    {
        public static void Main(string[] args)
        {
            FileStream stream = new FileStream(@"D:\student.dat", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            Student objStudent = new Student(101, "Nikhil", "Mumbai", "Bsc-IT");

            formatter.Serialize(stream, objStudent);
            Console.WriteLine("File Serialize Successfully......");
            stream.Close();

            Console.ReadLine();
        }
    }
}
