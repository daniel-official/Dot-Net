﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace LAB13_Q4
{
    class SupplierTest
    {
        public static Supplier sup = new Supplier();
        static void Main(string[] args)
        {

            Console.Write("Enter Supplier ID = ");
            sup.SupplierId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Supplier Name = ");
            sup.SupplierName = Console.ReadLine();
            Console.Write("Enter Supplier City = ");
            sup.City = Console.ReadLine();
            Console.Write("Enter Supplier Phone Number = ");
            sup.PhoneNo = Console.ReadLine();
            Console.Write("Enter Supplier Email = ");
            sup.Email = Console.ReadLine();

            sup.AccpetDetail(sup);
            XmlSerialization();
            XmlDeserialization();
            Console.ReadKey();
        }

        static void XmlSerialization()
        {
            FileStream objFS = new FileStream(@"D:\Serialization.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
            XmlSerializer objXmlS = new XmlSerializer(typeof(Supplier));
            objXmlS.Serialize(objFS, sup);
            objFS.Close();

            Console.WriteLine("-------------Serialization Sucessfull------------------");
        }
        static void XmlDeserialization()
        {
            XmlSerializer objXmlS = new XmlSerializer(typeof(Supplier));
            Supplier i; //creation of object of Supplier class
            using (Stream reader = new FileStream(@"D:\Serialization.xml", FileMode.Open))
            {
                // Call the Deserialize method to restore the object's state.
                i = objXmlS.Deserialize(reader) as Supplier;
            }
            Console.WriteLine("------------------- Supplier Detail------------------");
            Console.WriteLine("ID = {0}\tName = {1}\tCity = {2}\tphone No = {3}\tEmail = {4}", i.SupplierId, i.SupplierName, i.City, i.PhoneNo, i.Email);
            Console.WriteLine("-------------Deserialization Sucessfull------------------");
        }
    }
}
