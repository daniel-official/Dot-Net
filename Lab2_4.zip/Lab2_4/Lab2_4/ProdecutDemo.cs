﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_4
{
    public class ProdecutDemo
    {
        public object ProductId { get; set; }
        public object ProductName { get; set; }
        public object Price { get; set; }
        public object Quantity { get; set; }
        public Double AmountPayable { get; set; }

    }
}
